このフォルダはGitHub Pages用です。

1. GitHubでリポジトリを作成
2. index.html と images フォルダ内の画像をアップロード
3. Settings → Pages → Deploy from a branch → main / root を選択
4. 発行されたURLをLINEで共有

index.html と images フォルダは同じ階層に置いてください。
